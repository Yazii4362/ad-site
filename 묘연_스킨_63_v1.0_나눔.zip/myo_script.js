$(function () {
    $(window).on('load', function () {
        $('.revenue_unit_wrap').each(function () {
            $(this).parents().css('height', '');
        })
    })
});

$(function () {
    $('.category_list > li').has('.sub_category_list').addClass('mc');

    $('.mc').each(function () {
        var mc = $(this),
            cate = $(this).children('a.link_item'),
            cate2 = cate.clone(),
            href = cate.attr('href'),
            sub = $(this).find('.sub_category_list');

        function subAll() {
            sub.prepend("<li class=\"view-all\"></li>");
            mc.find('.view-all').prepend(cate2).children().removeClass('link_item').addClass('link_sub_item');
            cate.removeAttr('href');
        }

        if ($('.catebox.sub.sub-all').length) {
            if ($(window).width() > 767) {
                subAll();
            }
        }

        if ($(window).width() <= 767) {
            if ($('.catebox.msub').length) {
                subAll();

                $(mc).hover(function () {
                    $(this).siblings().find('.sub_category_list').stop().slideUp('200');
                    $(this).children('.sub_category_list').stop().slideDown('200');
                }, function () {
                    $(this).children('.sub_category_list').stop().slideUp('200');
                });

                $('.catebox a').filter('[href="' + location.pathname + '"]').addClass('on').closest('.mc').find('.link_item').addClass('on');
            }

        } else if ($('.catebox.sub').length) {
            $(mc).hover(function () {
                $(this).siblings().find('.sub_category_list').stop().slideUp('200');
                $(this).children('.sub_category_list').stop().slideDown('200');
            }, function () {
                $(this).children('.sub_category_list').stop().slideUp('200');
            });

            $('.catebox a').filter('[href="' + location.pathname + '"]').addClass('on').closest('.mc').find('.link_item').addClass('on');

        } else {
            $('.catebox a[href], #content .blogmenu a').filter('[href="' + location.pathname + '"]').addClass('on');
        }
        if ($('#content .blogmenu').length) {
            $('#content .blogmenu a').filter('[href="' + location.pathname + '"]').addClass('on');
        }
    });


    if ($('.newpost').length) {
        var newicon = newpost;
        $('.category_list > li img[alt="N"], .link_tit img, .myoskin .item .title img').each(function () {
            $(this).replaceWith('<span class=\"new\">' + newicon + '</span>');
        });
    }

    var myurl = window.location.origin.split('/');
    $(window).on('load', function () {
        if ($('.info_profile .txt_id[href$="' + myurl[2] + '"]').length) {
            $('.owner').show();
        } else {
            $('.owner').hide();
        }
    });

    $('.submenu, .sns').each(function () {
        if ($(this).children().length == false) {
            $(this).remove();
        }
    });

    $('.cate-btn').click(function () {
        $(this).closest('#header').toggleClass('active');
        $('.catebox').fadeToggle('fast');
    });
});

$(function () {
    $('#myoList .item').each(function () {
        var secret = $(this).find('.text').children().text(),
            text = '보호되어 있는 글입니다.';

        if (secret.indexOf(text) > -1) {
            $(this).addClass('lock');
        }
    });
});

$(function () {
    $('.text-item').each(function () {
        var opencmt = $(this).find('#opencmt'),
            shareSns = $(this).find('.tt-share-entry-with-sns'),
            tags = $(this).find('.tags');

        $(this).find('.container_postbtn').prepend(opencmt);

        $(tags).insertBefore($(this).find('.container_postbtn'));

        $(this).find('.postbtn_like').after(shareSns);

    });

    $('.text-item p:not(:last-child) > a:only-child').each(function () {
        $(this).parent().addClass('margin');
    })
    $('.text-item p:last-child:not(:first-child) > a:only-child').each(function () {
        $(this).parent().addClass('margint');
    })

    $('[data-ke-style="normal"]').each(function () {
        $(this).attr('data-ke-style', 'style1');
    });
    $('[data-ke-style="box"]').each(function () {
        $(this).attr('data-ke-style', 'style3');
    });

    $('div[data-ke-type="moreLess"]').each(function () {
        var remove = $(this),
            button = $(remove).attr('data-text-more');
        $(remove).find('.moreless-content').append('<div class="btn_less"></div>');
        $(remove).find('.btn_less').click(function () {
            $(remove).removeClass('open');
            $(remove).find('.btn-toggle-moreless').text(button);
        });

        if ($('#content.moreless-auto-semi').length) {
            var moretitle = $(this).attr('data-text-more');
            $(this).attr('data-text-more', moretitle);
            $(this).children('.btn-toggle-moreless').text(moretitle);
        } else if ($('#content.moreless-auto').length) {
            var moretitle = $(this).find('.moreless-content').children('p:first-child').text();
            $(this).attr('data-text-more', moretitle);
            $(this).children('.btn-toggle-moreless').text(moretitle);
        }
    });

    setTimeout(function () {
        $('.moreless_content .txt_view').each(function () {
            $(this).nextAll().slice(0, -1).wrapAll('<div class="more-txt"></div>');
        });

        $('.moreless_content .more-txt').each(function () {
            $(this).children('p:last-child:empty').remove();
        });
    }, 500);

    $('.text-item .imageblock img').closest('.tx-link').addClass('imgblock');

    $('figure[data-ke-type="video"] iframe').each(function () {
        var width = $(this).attr('width'),
            height = $(this).attr('height');
        if (width == 860) {
            $(this).attr('width', '560').attr('height', '315');
        } else if (width == 640) {
            $(this).attr('width', '560').attr('height', '315');
        } else if (height == 860) {
            $(this).attr('width', '315').attr('height', '560');
        } else if (height == 640) {
            $(this).attr('width', '315').attr('height', '560');
        }
    });

    $('.text-item iframe, .cmt .lst .text iframe').each(function () {
        var width = $(this).attr('width'),
            height = $(this).attr('height');
        if (width / height === 16 / 9) {
            $(this).wrap('<div class=\"framebox\"></div>');
        }
        if (width / height === 9 / 16) {
            $(this).wrap('<div class=\"framebox ver\"></div>');
        }
    });
});

$(function () {
    $(' a.opencmt').click(function () {
        $(this).closest('.post').find('#rp').slideToggle('slow').toggleClass('open');
        $('html,body').animate({
                scrollTop: $(this).closest('.post').find('#rp').offset().top - 50
            },
            'slow');
        return false;
    });

    $('.lst .reply .info a.re').each(function () {
        $(this).attr('onclick', $(this).closest('.cmtlst').find('.truere').attr('onclick'));
    })

    $('#article .post #rp').each(function () {
        if ($(this).find('.write').length == false) {
            $(this).closest('.post').find('#opencmt').hide();
        }
    });
});

$(function () {
    $('.cnt').each(function () {
        var bracket = $(this).html();
        $(this).html(bracket.replace('(', '').replace(')', '').replace(/^0+/, ''));
        $('.cnt span:empty').parent().hide();
        if ($('.myo_gal').length) {
            if ($(this).is(':not(:empty)')) {
                var num = Number($(this).text());

                function pad2(number) {
                    return (number < 10 ? '0' : '') + number
                }
                $(this).text(pad2(num));
            }
        }
    });
});

$(function () {
    $('.tags').each(function () {
        var comma = $(this).html();
        $(this).html(comma.replace(/,/g, ''));
    });
});

$(function () {
    function smoothScreen() {
        $('a[href]:not([href*="#"]):not([target=_blank]):not(a[href*="#"]):not(a[href=""]):not(a[href*=cfile])').not('.cmt .name a').click(function (e) {
            e.preventDefault();
            $link = $(this).attr("href");
            $('#container, .copy').fadeOut(1000, function () {
                window.location = $link;
            });
        });
        window.onpageshow = function (event) {
            if (event.persisted) {
                document.location.reload();
            }
        };
    }

    if ($('.smooth-screen-fade').length) {
        smoothScreen();
    } else if ($('.smooth-screen-loading').length) {
        $(window).on('load', function () {
            $('#loading').fadeOut('slow');
        });
        smoothScreen();
    }
});

$(function () {
    if ($('.smooth-scroll').length) {
        $('html, .scroll').easeScroll();
    }
});

$(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.top').fadeIn();
        } else {
            $('.top').fadeOut();
        }
    });
    $('.top').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
});

$(function () {
    console.log('myoyoun tistory skin 63 free # * https://sweet-myo.tistory.com/');
});

$(function () {
    var key = new Array();
    key['g'] = '/guestbook/';
    key['h'] = '/';
    key['m'] = '/manage/newpost/' + location.pathname.split('/')[1];
    key['n'] = '/manage/notice/';
    key['w'] = '/manage/newpost/';

    var key2 = new Array();
    key2['e'] = '/manage/design/skin/edit#/';

    function getKey(keyStroke) {
        if ((event.srcElement.tagName != 'INPUT') && (event.srcElement.tagName != 'TEXTAREA')) {
            isNetscape = (document.all);
            eventChooser = (isNetscape) ? keyStroke.which : event.keyCode;
            which = String.fromCharCode(eventChooser).toLowerCase();
            for (var i in key)
                if (which == i) window.location = key[i];
            for (var i in key2)
                if (which == i) window.open(key2[i], '_blank');
        }
    }
    document.onkeypress = getKey;
});

$(function () {
    setTimeout(function () {
        if ($(window).width() > 1260) {
            if ($('.toolbar_rb > .btn_tool').length) {
                $('.copy').css({
                    'left': '10px',
                    'right': 'auto'
                });
                $('.top').css({
                    'right': '20px',
                    'bottom': '65px'
                });
            }
        }
    }, 100);
});

$(function () {
    var agent = navigator.userAgent.toLowerCase();
    if ((navigator.appName == 'Netscape' && agent.indexOf('trident') != -1) || (agent.indexOf('msie') != -1)) {
        $('body').prepend('<div id=\"ie\"><span>지금 보시는 사이트는 <a href=\"//www.google.com/intl/ko/chrome/\" target=\"_blank\">크롬</a> / <a href=\"//whale.naver.com/ko/\" target=\"_blank\">웨일</a> / <a href=\"//www.opera.com/ko\" target=\"_blank\">오페라</a> / <a href=\"//vivaldi.com/\" target=\"_blank\">비발디</a>등 크로미움 브라우저에 최적화 되어있습니다</span></div>');
        $('#ie').fadeIn();
    }
    setTimeout(function () {
        $('#ie').fadeOut()
    }, 5000);
});
